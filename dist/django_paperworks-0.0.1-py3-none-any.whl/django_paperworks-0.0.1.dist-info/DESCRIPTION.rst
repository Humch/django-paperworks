++++++++++++++++++
Django Paperworks
++++++++++++++++++

Paperworks is a Django app to store and to sort personal paperworks.

Detailed documentation is in the "docs" directory.

